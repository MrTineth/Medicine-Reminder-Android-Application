package com.example.medmanager;

import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
}